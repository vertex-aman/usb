def calculate_risk(total_files, suspicious_files):

    score = 0

    if suspicious_files == 0:
        return 0, "LOW"

    percentage = (suspicious_files / total_files) * 100

    if percentage < 2:
        score = 25

    elif percentage < 5:
        score = 50

    elif percentage < 10:
        score = 75

    else:
        score = 100

    if score <= 25:
        level = "LOW"

    elif score <= 50:
        level = "MEDIUM"

    elif score <= 75:
        level = "HIGH"

    else:
        level = "CRITICAL"

    return score, level