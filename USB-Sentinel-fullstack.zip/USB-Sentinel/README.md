# USB Sentinel
React frontend + FastAPI backend + MySQL + Windows Python agent. Your original modules (`usb.py`, `scanner.py`, `hashing.py`, `risk.py`, `report.py`, `main.py`) are kept; the agent reuses `usb.py`, `scanner.py` and `hashing.py`.

```
USB-Sentinel/
  agent/agent.py        detects USB + scans (Windows)
  backend/app/          FastAPI, SQLAlchemy models, risk_engine.py, virustotal.py
  frontend/             React + Vite UI
  database/setup.sql    creates MySQL database and user
  .env.example
```
Flow: agent -> backend (HTTP, X-Agent-Key) -> MySQL <- backend <- frontend (Axios, polls every 3 s).

## 1. MySQL
1. Install MySQL Server 8 (mysql.com/downloads/installer) and remember the root password.
2. Edit the password in `database/setup.sql`, then run:
   `mysql -u root -p < database/setup.sql`
3. Tables are created automatically on first backend start.

## 2. Configure
Copy `.env.example` to `.env` in the project root and set `DB_PASSWORD` (same as setup.sql), `AGENT_KEY` (any long random text) and optionally `VT_API_KEY` (free key from virustotal.com, Profile > API key). Never commit `.env`.

## 3. Backend (terminal 1)
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.app.main:app --reload --port 8000
```
Open http://localhost:8000/docs (Swagger) and http://localhost:8000/api/health (should show database "connected").

## 4. Frontend (terminal 2)
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173.

## 5. Agent (terminal 3, Windows, same venv)
```
venv\Scripts\activate
python agent\agent.py
```
Insert a USB drive: it appears on the dashboard within ~3 s and is scanned automatically.

## Troubleshooting
- `Access denied for user`: DB_USER/DB_PASSWORD in `.env` do not match setup.sql.
- `Can't connect to MySQL`: start the MySQL service (services.msc).
- `ModuleNotFoundError: backend`: run uvicorn from the project root, not inside `backend/`.
- Frontend says "Backend unavailable": backend not running or CORS origin differs from localhost:5173.
- Agent prints `AGENT_KEY rejected`: key in `.env` changed after backend started; restart backend.
- `wmi` / `pywin32` errors: agent only runs on Windows.
- VirusTotal "disabled": `VT_API_KEY` empty. "error": key invalid. Free tier allows 4 lookups/min; the backend waits 16 s between lookups and checks at most 20 suspicious hashes per scan.

## Deploying the frontend
Only the `frontend/` folder can go to Vercel/Netlify (root directory `frontend`). The USB agent must run on the monitored PC, and the backend + MySQL must be reachable from the agent, so set `VITE_API_URL` to your public backend URL before building.
