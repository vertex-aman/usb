import wmi

c = wmi.WMI()


def get_usb_drives():
    """
    Returns a list of connected removable USB drives.
    """

    drives = []

    try:
        for disk in c.Win32_LogicalDisk():

            if disk.DriveType == 2:

                drives.append({
                    "drive": disk.DeviceID + "\\",
                    "label": disk.VolumeName if disk.VolumeName else "No Label",
                    "filesystem": disk.FileSystem,
                    "size": int(disk.Size) if disk.Size else 0,
                    "serial": disk.VolumeSerialNumber or ""
                })

    except Exception as e:
        print("USB Detection Error:", e)

    return drives