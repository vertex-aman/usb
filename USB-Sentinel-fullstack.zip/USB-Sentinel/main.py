from usb import get_usb_drives
from scanner import scan_drive
from hashing import calculate_hash
from report import generate_html_report
from risk import calculate_risk

print("=" * 65)
print("                 USB Sentinel v1.0")
print("=" * 65)

drives = get_usb_drives()

if not drives:
    print("\nNo USB device detected.")
    exit()

print("\nUSB Devices Found:\n")

for index, drive in enumerate(drives, start=1):

    print(f"[{index}] {drive['drive']}")
    print(f"    Label       : {drive['label']}")
    print(f"    File System : {drive['filesystem']}")
    print(f"    Capacity    : {drive['size']/(1024**3):.2f} GB")
    print("-" * 60)

selected = int(input("\nSelect USB Drive : ")) - 1

drive_path = drives[selected]["drive"]

print("\nScanning USB...")
print("=" * 65)

files, suspicious = scan_drive(drive_path)
score, level = calculate_risk(
    len(files),
    len(suspicious)
)

print(f"\nTotal Files Found      : {len(files)}")
print(f"Suspicious Files Found : {len(suspicious)}")
print(f"Risk Score             : {score}/100")
print(f"Risk Level             : {level}")

if not suspicious:

    print("\nNo suspicious files found.")
    exit()

print("\nPotentially Suspicious Files\n")

for count, file in enumerate(suspicious, start=1):

    print(f"[{count}] {file['name']}")
    print(f"     Extension : {file['extension']}")
    print(f"     Size      : {file['size']} Bytes")

    sha256 = calculate_hash(file["path"])
    file["sha256"] = sha256
    print(f"     SHA256    : {sha256}")

    print("-" * 65)

print("\nScan Completed Successfully.")
report = generate_html_report(
    drives[selected],
    files,
    suspicious,
    score,
    level

)

print("\nHTML Report Generated Successfully!")
print(f"Report saved at: {report}")
