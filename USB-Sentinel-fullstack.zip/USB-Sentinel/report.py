from datetime import datetime
import os


def generate_html_report(drive_info, files, suspicious, score, level):
    os.makedirs("reports", exist_ok=True)

    report_name = f"reports/USB_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

    html = f"""
    <html>
    <head>
        <title>USB Sentinel Report</title>

        <style>

        body {{
            font-family: Arial;
            background:#f5f5f5;
            margin:40px;
        }}

        h1 {{
            color:#1565C0;
        }}

        table {{
            border-collapse:collapse;
            width:100%;
            background:white;
        }}

        th,td {{
            border:1px solid #ddd;
            padding:8px;
        }}

        th {{
            background:#1565C0;
            color:white;
        }}

        .danger {{
            color:red;
            font-weight:bold;
        }}

        </style>

    </head>

    <body>

    <h1>USB Sentinel Investigation Report</h1>

    <h2>USB Information</h2>

    <table>

    <tr><th>Drive</th><td>{drive_info['drive']}</td></tr>

    <tr><th>Label</th><td>{drive_info['label']}</td></tr>

    <tr><th>File System</th><td>{drive_info['filesystem']}</td></tr>

    <tr><th>Total Files</th><td>{len(files)}</td></tr>

    <tr><th>Suspicious Files</th><td class="danger">{len(suspicious)}</td></tr>
    <tr><th>Risk Score</th><td>{score}/100</td></tr>
    <tr><th>Risk Level</th><td>{level}</td></tr>
    </table>

    <br>

    <h2>Suspicious Files</h2>

    <table>

    <tr>

    <th>File Name</th>

    <th>Extension</th>

    <th>Size(Bytes)</th>

    <th>SHA256</th>

    </tr>

    """

    for f in suspicious:

        html += f"""

        <tr>

        <td>{f['name']}</td>

        <td>{f['extension']}</td>

        <td>{f['size']}</td>

        <td>{f.get('sha256','')}</td>

        </tr>

        """

    html += """

    </table>

    </body>

    </html>

    """

    with open(report_name, "w", encoding="utf-8") as report:

        report.write(html)

    return report_name