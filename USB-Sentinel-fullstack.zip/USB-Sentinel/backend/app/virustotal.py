import os, time, threading
from datetime import datetime, timedelta
import requests
from .db import SessionLocal
from .models import ScannedFile, VtCache, Scan, Device, Event, Alert
from .risk_engine import score_file, score_scan, level

URL = "https://www.virustotal.com/api/v3/files/"

def lookup(sha):
    """Hash-only lookup. Returns dict(status=found|not_found|error|rate_limited, counts...). Never uploads files."""
    key = os.getenv("VT_API_KEY", "").strip()
    try:
        r = requests.get(URL + sha, headers={"x-apikey": key}, timeout=15)
    except requests.RequestException:
        return {"status": "error"}
    if r.status_code == 200:
        st = r.json()["data"]["attributes"]["last_analysis_stats"]
        return {"status": "found", "malicious": st.get("malicious", 0), "suspicious": st.get("suspicious", 0),
                "harmless": st.get("harmless", 0), "undetected": st.get("undetected", 0)}
    if r.status_code == 404: return {"status": "not_found"}
    if r.status_code == 429: return {"status": "rate_limited"}
    return {"status": "error"}  # 401 invalid key etc.

def apply(db, f, res):
    f.vt_status = res["status"]; f.vt_checked_at = datetime.utcnow()
    f.vt_malicious, f.vt_suspicious = res.get("malicious"), res.get("suspicious")
    f.vt_harmless, f.vt_undetected = res.get("harmless"), res.get("undetected")

def recompute(db, scan):
    scores = []
    for f in scan.files:
        if f.status != "hashed": continue
        vt = {"status": f.vt_status, "malicious": f.vt_malicious}
        f.risk_score, why = score_file(f.name, f.extension or "", vt)
        f.risk_level, f.reasons = level(f.risk_score), "; ".join(why)
        scores.append(f.risk_score)
    scan.risk_score = score_scan(scores); scan.risk_level = level(scan.risk_score)
    scan.suspicious_files = len([x for x in scores if x >= 25])
    dev = scan.device
    dev.risk_score, dev.risk_level = scan.risk_score, scan.risk_level
    top = sorted([f for f in scan.files if f.risk_score >= 25], key=lambda f: -f.risk_score)[:5]
    dev.risk_reasons = "\n".join(f"{f.name}: {f.reasons}" for f in top) or "No suspicious indicators found (this does not guarantee the drive is safe)."
    for f in scan.files:
        if f.risk_score >= 50 and not db.query(Alert).filter_by(title=f"{f.risk_level} risk file", file_name=f.name, device_name=dev.label).first():
            db.add(Alert(severity=f.risk_level, title=f"{f.risk_level} risk file", reason=f.reasons, device_name=dev.label, file_name=f.name))
            db.add(Event(type="Suspicious File", message=f"{f.name}: {f.reasons}", device_name=dev.label))

def run_checks(scan_id):
    """Background thread: look up suspicious hashes only, respecting the free-tier rate limit."""
    db = SessionLocal()
    try:
        scan = db.get(Scan, scan_id)
        files = [f for f in scan.files if f.status == "hashed" and f.risk_score >= 25 and f.sha256]
        enabled = bool(os.getenv("VT_API_KEY", "").strip())
        for i, f in enumerate(files[:20]):
            if not enabled:
                f.vt_status = "disabled"; continue
            c = db.get(VtCache, f.sha256)
            if c and c.checked_at > datetime.utcnow() - timedelta(hours=24) and c.status in ("found", "not_found"):
                apply(db, f, {"status": c.status, "malicious": c.malicious, "suspicious": c.suspicious, "harmless": c.harmless, "undetected": c.undetected}); continue
            res = lookup(f.sha256)
            if res["status"] == "rate_limited": f.vt_status = "pending"; time.sleep(60); res = lookup(f.sha256)
            apply(db, f, res)
            if res["status"] in ("found", "not_found"):
                db.merge(VtCache(sha256=f.sha256, status=res["status"], malicious=res.get("malicious"), suspicious=res.get("suspicious"),
                                 harmless=res.get("harmless"), undetected=res.get("undetected"), checked_at=datetime.utcnow()))
            db.commit()
            if i < len(files) - 1: time.sleep(16)
        recompute(db, scan)
        db.add(Event(type="Malware Check", message=f"VirusTotal check finished for scan #{scan.id}" if enabled else "VirusTotal not configured; local analysis only", device_name=scan.device.label))
        db.commit()
    except Exception as e:  # never crash the server thread
        db.rollback(); print("VT thread error:", e)
    finally:
        db.close()

def start(scan_id):
    threading.Thread(target=run_checks, args=(scan_id,), daemon=True).start()
