"""Risk rules live here so they are easy to change. Bands: 0-24 Low, 25-49 Medium, 50-74 High, 75-100 Critical."""
EXEC = {".exe", ".dll", ".scr", ".msi", ".com", ".jar", ".hta"}
SCRIPT = {".bat", ".cmd", ".vbs", ".ps1", ".js"}
DOCS = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".jpg", ".png"}

def level(score):
    return "Critical" if score >= 75 else "High" if score >= 50 else "Medium" if score >= 25 else "Low"

def score_file(name, ext, vt=None):
    """Returns (score, [reasons]). Indicators are NOT confirmed malware; only VirusTotal hits are reported as detections."""
    s, why = 0, []
    n = name.lower()
    if n == "autorun.inf":
        s += 60; why.append("autorun.inf can make Windows launch a program automatically (indicator)")
    elif ext == ".inf":
        s += 15; why.append(".inf setup file (indicator)")
    if ext in EXEC:
        s += 30; why.append(f"Executable file type {ext} (indicator, not proof of malware)")
    if ext in SCRIPT:
        s += 25; why.append(f"Script file type {ext} (indicator)")
    parts = n.rsplit(".", 2)
    if len(parts) == 3 and "." + parts[1] in DOCS and ext in EXEC | SCRIPT:
        s += 30; why.append("Double extension disguises an executable as a document")
    if vt and vt.get("status") == "found":
        m = vt.get("malicious") or 0
        if m >= 5: s += 70; why.append(f"VirusTotal: {m} engines flagged this hash as malicious")
        elif m >= 1: s += 40; why.append(f"VirusTotal: {m} engine(s) flagged this hash (low-confidence)")
    return min(s, 100), why

def score_scan(file_scores):
    flagged = [x for x in file_scores if x >= 25]
    if not file_scores: return 0
    top = max(file_scores)
    return min(100, top + min(15, 3 * max(len(flagged) - 1, 0)))
