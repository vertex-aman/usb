import os, json
from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import FastAPI, Depends, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import func, or_, text
from sqlalchemy.orm import Session
from .db import Base, engine, get_db, SessionLocal
from .models import Device, Scan, ScannedFile, Event, Alert
from . import virustotal as vt
from .risk_engine import score_file, level

app = FastAPI(title="USB Sentinel API", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["*"], allow_headers=["*"])
Base.metadata.create_all(engine)  # creates tables on first start
agent = {"last_seen": None, "online": False}

def need_agent(x_agent_key: str = Header(default="")):
    if not os.getenv("AGENT_KEY") or x_agent_key != os.getenv("AGENT_KEY"):
        raise HTTPException(401, "Invalid agent key")

def ev(db, type_, msg, dev=""):
    db.add(Event(type=type_, message=msg, device_name=dev))

def iso(d): return d.isoformat() + "Z" if d else None
def dev_out(d):
    return dict(id=d.id, label=d.label, drive=d.drive, filesystem=d.filesystem, size_bytes=d.size_bytes, serial=d.serial or None,
                connected=d.connected, connected_at=iso(d.connected_at), disconnected_at=iso(d.disconnected_at), last_scan_at=iso(d.last_scan_at),
                risk_score=d.risk_score, risk_level=d.risk_level, risk_reasons=d.risk_reasons or "")
def scan_out(s):
    return dict(id=s.id, device_id=s.device_id, device=s.device.label, drive=s.drive, status=s.status, created_at=iso(s.created_at), finished_at=iso(s.finished_at),
                total_files=s.total_files, skipped_files=s.skipped_files, suspicious_files=s.suspicious_files, risk_score=s.risk_score, risk_level=s.risk_level, error=s.error)
def file_out(f):
    return dict(id=f.id, scan_id=f.scan_id, name=f.name, path=f.path, extension=f.extension, size=f.size, sha256=f.sha256, status=f.status, risk_score=f.risk_score,
                risk_level=f.risk_level, reasons=f.reasons, vt_status=f.vt_status, vt_malicious=f.vt_malicious, vt_suspicious=f.vt_suspicious,
                vt_harmless=f.vt_harmless, vt_undetected=f.vt_undetected, vt_checked_at=iso(f.vt_checked_at))

@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok", "database": "connected"}

# ---------- agent endpoints (protected by X-Agent-Key) ----------
class Heartbeat(BaseModel):
    hostname: str = ""
@app.post("/api/agent/heartbeat", dependencies=[Depends(need_agent)])
def heartbeat(b: Heartbeat, db: Session = Depends(get_db)):
    if not agent["online"]:
        ev(db, "Agent", f"Agent connected ({b.hostname})"); db.commit()
    agent.update(last_seen=datetime.utcnow(), online=True)
    return {"ok": True}

class DeviceEvent(BaseModel):
    event: str
    drive: str
    label: str = "No Label"
    filesystem: Optional[str] = ""
    size: int = 0
    serial: Optional[str] = ""
@app.post("/api/agent/device-event", dependencies=[Depends(need_agent)])
def device_event(b: DeviceEvent, db: Session = Depends(get_db)):
    if b.event not in ("connected", "disconnected"): raise HTTPException(422, "event must be connected or disconnected")
    key = b.serial or f"{b.label}-{b.size}-{b.filesystem}"
    d = db.query(Device).filter_by(device_key=key).first()
    if not d:
        d = Device(device_key=key, label=b.label, drive=b.drive, filesystem=b.filesystem, size_bytes=b.size, serial=b.serial); db.add(d); db.flush()
    if b.event == "connected":
        if d.connected and d.drive == b.drive: return {"id": d.id, "duplicate": True}   # repeated event
        d.connected, d.drive, d.label, d.connected_at, d.disconnected_at = True, b.drive, b.label, datetime.utcnow(), None
        ev(db, "Connected", f"USB inserted at {b.drive} ({b.filesystem}, {b.size/1024**3:.1f} GB)", d.label)
        if os.getenv("AUTO_SCAN", "true").lower() == "true": db.add(Scan(device_id=d.id, drive=b.drive))
    else:
        if not d.connected: return {"id": d.id, "duplicate": True}
        d.connected, d.disconnected_at = False, datetime.utcnow()
        ev(db, "Disconnected", f"USB removed from {d.drive}", d.label)
    db.commit(); return {"id": d.id}

@app.get("/api/agent/pending-scans", dependencies=[Depends(need_agent)])
def pending(db: Session = Depends(get_db)):
    out = []
    for s in db.query(Scan).filter_by(status="pending").all():
        s.status = "running"; ev(db, "Scan Started", f"Scan #{s.id} started on {s.drive}", s.device.label); out.append({"id": s.id, "drive": s.drive})
    db.commit(); return out

class FileIn(BaseModel):
    name: str; path: str; extension: str = ""; size: int = 0; sha256: Optional[str] = None; skipped: bool = False
@app.post("/api/agent/scans/{sid}/files", dependencies=[Depends(need_agent)])
def add_files(sid: int, files: List[FileIn], db: Session = Depends(get_db)):
    s = db.get(Scan, sid)
    if not s: raise HTTPException(404, "Scan not found")
    for f in files:
        if f.skipped or not f.sha256:
            db.add(ScannedFile(scan_id=sid, name=f.name, path=f.path, extension=f.extension, size=f.size, status="skipped", risk_level="Unknown", vt_status="not_checked")); s.skipped_files += 1
        else:
            sc, why = score_file(f.name, f.extension)
            db.add(ScannedFile(scan_id=sid, name=f.name, path=f.path, extension=f.extension, size=f.size, sha256=f.sha256, risk_score=sc, risk_level=level(sc), reasons="; ".join(why)))
        s.total_files += 1
    db.commit(); return {"received": len(files)}

class Done(BaseModel):
    ok: bool = True
    error: Optional[str] = None
@app.post("/api/agent/scans/{sid}/complete", dependencies=[Depends(need_agent)])
def complete(sid: int, b: Done, db: Session = Depends(get_db)):
    s = db.get(Scan, sid)
    if not s: raise HTTPException(404, "Scan not found")
    s.finished_at = datetime.utcnow(); s.device.last_scan_at = s.finished_at
    if not b.ok:
        s.status, s.error = "failed", b.error; ev(db, "Scan Failed", f"Scan #{sid}: {b.error}", s.device.label)
    else:
        s.status = "completed"; vt.recompute(db, s)
        ev(db, "Scan Completed", f"Scan #{sid}: {s.total_files} files, {s.suspicious_files} suspicious, risk {s.risk_level}", s.device.label)
    db.commit()
    if b.ok: vt.start(sid)
    return {"ok": True}

# ---------- frontend endpoints ----------
@app.get("/api/devices")
def devices(db: Session = Depends(get_db)):
    return [dev_out(d) for d in db.query(Device).order_by(Device.connected.desc(), Device.connected_at.desc()).all()]

@app.get("/api/devices/{did}")
def device(did: int, db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d: raise HTTPException(404, "Device not found")
    scans = db.query(Scan).filter_by(device_id=did).order_by(Scan.id.desc()).limit(10).all()
    return {**dev_out(d), "scans": [scan_out(s) for s in scans]}

@app.post("/api/devices/{did}/scan", status_code=202)
def start_scan(did: int, db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d: raise HTTPException(404, "Device not found")
    if not d.connected: raise HTTPException(409, "Device is not connected")
    if db.query(Scan).filter(Scan.device_id == did, Scan.status.in_(["pending", "running"])).first(): raise HTTPException(409, "A scan is already in progress")
    s = Scan(device_id=did, drive=d.drive); db.add(s); db.commit(); return {"scan_id": s.id}

@app.get("/api/scans/{sid}")
def get_scan(sid: int, db: Session = Depends(get_db)):
    s = db.get(Scan, sid)
    if not s: raise HTTPException(404, "Scan not found")
    return scan_out(s)

@app.get("/api/files")
def files(q: str = "", risk: str = "All", status: str = "All", limit: int = Query(300, le=5000), db: Session = Depends(get_db)):
    qs = db.query(ScannedFile)
    if q: qs = qs.filter(or_(ScannedFile.name.like(f"%{q}%"), ScannedFile.sha256.like(f"{q}%")))
    if risk != "All": qs = qs.filter(ScannedFile.risk_level == risk)
    if status != "All": qs = qs.filter(ScannedFile.vt_status == status)
    return [file_out(f) for f in qs.order_by(ScannedFile.risk_score.desc(), ScannedFile.id.desc()).limit(limit).all()]

@app.get("/api/events")
def events(limit: int = Query(200, le=1000), db: Session = Depends(get_db)):
    return [dict(id=e.id, type=e.type, message=e.message, device=e.device_name, time=iso(e.created_at)) for e in db.query(Event).order_by(Event.id.desc()).limit(limit)]

@app.get("/api/alerts")
def alerts(db: Session = Depends(get_db)):
    return [dict(id=a.id, severity=a.severity, title=a.title, reason=a.reason, device=a.device_name, file=a.file_name, status=a.status, time=iso(a.created_at))
            for a in db.query(Alert).order_by(Alert.id.desc()).limit(200)]

@app.patch("/api/alerts/{aid}")
def ack(aid: int, db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a: raise HTTPException(404, "Alert not found")
    a.status = "Acknowledged"; db.commit(); return {"ok": True}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    online = bool(agent["last_seen"] and datetime.utcnow() - agent["last_seen"] < timedelta(seconds=20))
    if agent["online"] and not online:
        agent["online"] = False; ev(db, "Agent Error", "Agent stopped responding (no heartbeat)"); db.commit()
    dist = {k: 0 for k in ["Low", "Medium", "High", "Critical", "Unscanned"]}
    for d in db.query(Device).all(): dist[d.risk_level or "Unscanned"] += 1
    sf = db.query(ScannedFile)
    return dict(backend="ok", agent_online=online, agent_last_seen=iso(agent["last_seen"]),
        total_devices=db.query(Device).count(), connected_devices=db.query(Device).filter_by(connected=True).count(),
        files_scanned=sf.filter_by(status="hashed").count(), suspicious_files=sf.filter(ScannedFile.risk_score >= 25).count(),
        high_critical=sf.filter(ScannedFile.risk_level.in_(["High", "Critical"])).count(),
        running_scans=db.query(Scan).filter(Scan.status.in_(["pending", "running"])).count(), distribution=dist,
        recent_scans=[scan_out(s) for s in db.query(Scan).order_by(Scan.id.desc()).limit(5)])
