from datetime import datetime
from sqlalchemy import Column, Integer, BigInteger, String, Boolean, DateTime, Text, ForeignKey, Index
from sqlalchemy.orm import relationship
from .db import Base

now = datetime.utcnow

class Device(Base):
    __tablename__ = "usb_devices"
    id = Column(Integer, primary_key=True)
    device_key = Column(String(128), unique=True, nullable=False)
    label = Column(String(255)); drive = Column(String(16)); filesystem = Column(String(32))
    size_bytes = Column(BigInteger, default=0); serial = Column(String(64))
    connected = Column(Boolean, default=False, index=True)
    first_seen = Column(DateTime, default=now); connected_at = Column(DateTime); disconnected_at = Column(DateTime)
    last_scan_at = Column(DateTime); risk_score = Column(Integer); risk_level = Column(String(16))
    risk_reasons = Column(Text, default="")
    scans = relationship("Scan", back_populates="device")

class Scan(Base):
    __tablename__ = "scans"
    id = Column(Integer, primary_key=True)
    device_id = Column(Integer, ForeignKey("usb_devices.id"), index=True, nullable=False)
    drive = Column(String(16)); status = Column(String(16), default="pending", index=True)
    created_at = Column(DateTime, default=now); finished_at = Column(DateTime)
    total_files = Column(Integer, default=0); skipped_files = Column(Integer, default=0); suspicious_files = Column(Integer, default=0)
    risk_score = Column(Integer); risk_level = Column(String(16)); error = Column(Text)
    device = relationship("Device", back_populates="scans")
    files = relationship("ScannedFile", back_populates="scan", cascade="all, delete-orphan")

class ScannedFile(Base):
    __tablename__ = "scanned_files"
    id = Column(Integer, primary_key=True)
    scan_id = Column(Integer, ForeignKey("scans.id"), index=True, nullable=False)
    name = Column(String(512)); path = Column(Text); extension = Column(String(32)); size = Column(BigInteger, default=0)
    sha256 = Column(String(64), index=True); status = Column(String(16), default="hashed")
    risk_score = Column(Integer, default=0); risk_level = Column(String(16), default="Low"); reasons = Column(Text, default="")
    vt_status = Column(String(16), default="not_checked")
    vt_malicious = Column(Integer); vt_suspicious = Column(Integer); vt_harmless = Column(Integer); vt_undetected = Column(Integer)
    vt_checked_at = Column(DateTime)
    scan = relationship("Scan", back_populates="files")

class VtCache(Base):
    __tablename__ = "vt_cache"
    sha256 = Column(String(64), primary_key=True); status = Column(String(16))
    malicious = Column(Integer); suspicious = Column(Integer); harmless = Column(Integer); undetected = Column(Integer)
    checked_at = Column(DateTime, default=now)

class Event(Base):
    __tablename__ = "security_events"
    id = Column(Integer, primary_key=True)
    type = Column(String(32), index=True); message = Column(Text); device_name = Column(String(255))
    created_at = Column(DateTime, default=now, index=True)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    severity = Column(String(16), index=True); title = Column(String(255)); reason = Column(Text)
    device_name = Column(String(255)); file_name = Column(String(512)); status = Column(String(16), default="Open")
    created_at = Column(DateTime, default=now, index=True)
Index("ix_alert_dedupe", Alert.title, Alert.file_name)
