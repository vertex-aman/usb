import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api, errMsg } from '../services/api.js';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [data, setData] = useState({ dashboard: null, devices: [], events: [], alerts: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toasts, setToasts] = useState([]);

  const toast = useCallback((msg, kind = 'info') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
  }, []);

  const load = useCallback(async () => {
    try {
      const [dashboard, devices, events, alerts] = await Promise.all([api.dashboard(), api.devices(), api.events(), api.alerts()]);
      setData({ dashboard, devices, events, alerts }); setError(null);
    } catch (e) { setError(errMsg(e)); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t); }, [load]);

  return (
    <Ctx.Provider value={{ ...data, loading, error, reload: load, toast }}>
      {children}
      <div className="toasts">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>)}</div>
    </Ctx.Provider>
  );
}
