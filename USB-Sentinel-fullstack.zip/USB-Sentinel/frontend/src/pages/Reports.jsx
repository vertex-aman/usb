import { Download } from 'lucide-react';
import { useApp } from '../hooks/useApp.jsx';
import { api, errMsg } from '../services/api.js';
import { Card, PageHead, State } from '../components/UI.jsx';
import { downloadCsv } from '../utils/index.js';

export default function Reports() {
  const { dashboard: d, devices, events, alerts, loading, error, reload, toast } = useApp();
  const exp = async (name, getRows) => {
    try { const rows = await getRows(); if (!rows.length) return toast('Nothing to export yet', 'error'); downloadCsv(`usb-sentinel-${name}.csv`, rows); toast(`Exported ${name}.csv`, 'success'); }
    catch (e) { toast(errMsg(e), 'error'); }
  };
  const sets = [
    ['files', async () => (await api.files({ limit: 5000 })).map((f) => ({ name: f.name, path: f.path, ext: f.extension, size: f.size, sha256: f.sha256, risk: f.risk_level, score: f.risk_score, reasons: f.reasons, vt_status: f.vt_status, vt_malicious: f.vt_malicious }))],
    ['devices', async () => devices.map((x) => ({ label: x.label, drive: x.drive, serial: x.serial, connected: x.connected, last_scan: x.last_scan_at, risk: x.risk_level, score: x.risk_score }))],
    ['events', async () => events.map((e) => ({ time: e.time, type: e.type, device: e.device, message: e.message }))],
    ['alerts', async () => alerts.map((a) => ({ time: a.time, severity: a.severity, device: a.device, file: a.file, reason: a.reason, status: a.status }))],
  ];
  return (
    <>
      <PageHead title="Reports" sub="Real scan statistics and CSV export.">{sets.map(([n, g]) => <button key={n} className="btn" onClick={() => exp(n, g)}><Download size={14} /> {n}.csv</button>)}</PageHead>
      <Card title="Summary"><State loading={loading} error={error} onRetry={reload}>{d && <div className="grid4">
        {[['Devices', d.total_devices], ['Files scanned', d.files_scanned], ['Suspicious files', d.suspicious_files], ['High / Critical', d.high_critical]].map(([k, v]) => <div className="stat" key={k}><span>{k}</span><b>{v}</b></div>)}</div>}</State></Card>
      <Card title="Device risk"><div className="scroll"><table><thead><tr><th>Device</th><th>Drive</th><th>Risk</th><th>Score</th></tr></thead><tbody>{devices.map((x) => <tr key={x.id}><td>{x.label}</td><td>{x.drive}</td><td>{x.risk_level || 'Unscanned'}</td><td>{x.risk_score ?? '—'}</td></tr>)}</tbody></table></div></Card>
    </>
  );
}
