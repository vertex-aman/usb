import { useEffect, useState } from 'react';
import { api, errMsg } from '../services/api.js';
import { Card, PageHead, SearchBox, Select, State, RiskBadge, Badge } from '../components/UI.jsx';
import { fmtSize } from '../utils/index.js';

const vtText = (f) => (f.vt_status === 'found' ? `${f.vt_malicious} malicious · ${f.vt_suspicious} suspicious · ${f.vt_harmless} harmless · ${f.vt_undetected} undetected` : null);

export default function FileAnalysis() {
  const [q, setQ] = useState(''); const [risk, setRisk] = useState('All'); const [status, setStatus] = useState('All');
  const [rows, setRows] = useState([]); const [loading, setLoading] = useState(true); const [error, setError] = useState(null);
  const load = async () => { try { setRows(await api.files({ q, risk, status })); setError(null); } catch (e) { setError(errMsg(e)); } setLoading(false); };
  useEffect(() => { load(); const t = setInterval(load, 4000); return () => clearInterval(t); }, [q, risk, status]);
  return (
    <>
      <PageHead title="File Analysis" sub="Files hashed by the agent. VirusTotal lookups are hash-only; no file is uploaded.">
        <SearchBox value={q} onChange={setQ} placeholder="File name or SHA-256 prefix…" /><Select value={risk} onChange={setRisk} options={['All', 'Low', 'Medium', 'High', 'Critical']} />
        <Select value={status} onChange={setStatus} options={['All', 'not_checked', 'found', 'not_found', 'pending', 'error', 'disabled']} />
      </PageHead>
      <Card><State loading={loading} error={error} empty={!rows.length} onRetry={load}>
        <div className="scroll"><table><thead><tr><th>File</th><th>Type / Size</th><th>SHA-256</th><th>VirusTotal</th><th>Risk</th><th>Reason</th></tr></thead>
          <tbody>{rows.map((f) => <tr key={f.id}><td><b>{f.name}</b><small className="wrap">{f.path}</small></td><td>{f.extension || '—'}<small>{fmtSize(f.size)}</small></td>
            <td className="mono wrap">{f.sha256 ? f.sha256.slice(0, 20) + '…' : 'skipped'}</td>
            <td><Badge level={f.vt_status} />{vtText(f) && <small>{vtText(f)}</small>}</td><td>{f.status === 'skipped' ? <Badge level="Unknown">Not analyzed</Badge> : <RiskBadge level={f.risk_level} score={f.risk_score} />}</td>
            <td>{f.reasons || (f.status === 'skipped' ? 'File skipped (too large or unreadable)' : 'No indicators found (not a guarantee of safety)')}</td></tr>)}</tbody></table></div>
      </State></Card>
    </>
  );
}
