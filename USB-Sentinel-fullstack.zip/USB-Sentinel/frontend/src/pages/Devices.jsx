import { useMemo, useState } from 'react';
import { Eye, ScanLine } from 'lucide-react';
import { useApp } from '../hooks/useApp.jsx';
import { api, errMsg } from '../services/api.js';
import { PageHead, Card, SearchBox, Select, State, Modal, RiskBadge, Badge } from '../components/UI.jsx';
import { fmtDate, fmtSize } from '../utils/index.js';

export default function Devices() {
  const { devices, dashboard, loading, error, reload, toast } = useApp();
  const [q, setQ] = useState(''); const [f, setF] = useState('All'); const [sel, setSel] = useState(null);
  const rows = useMemo(() => devices.filter((d) => (f === 'All' || (f === 'Connected') === d.connected) && `${d.label} ${d.serial} ${d.drive}`.toLowerCase().includes(q.toLowerCase())), [devices, q, f]);
  const scanning = (id) => dashboard?.recent_scans.some((s) => s.device_id === id && ['pending', 'running'].includes(s.status));
  const scan = async (d) => { try { await api.scanDevice(d.id); toast('Scan queued. The agent will start it shortly.', 'success'); reload(); } catch (e) { toast(errMsg(e), 'error'); } };
  const open = async (d) => { try { setSel(await api.device(d.id)); } catch (e) { toast(errMsg(e), 'error'); } };
  return (
    <>
      <PageHead title="USB Devices" sub="Devices reported by the Python agent."><SearchBox value={q} onChange={setQ} placeholder="Search label, serial, drive…" /><Select value={f} onChange={setF} options={['All', 'Connected', 'Disconnected']} /></PageHead>
      <Card><State loading={loading} error={error} empty={!rows.length} onRetry={reload}>
        <div className="scroll"><table><thead><tr><th>Device</th><th>Drive</th><th>Serial</th><th>Status</th><th>Connected</th><th>Last scan</th><th>Risk</th><th /></tr></thead>
          <tbody>{rows.map((d) => <tr key={d.id}><td><b>{d.label}</b><small>{d.filesystem} · {fmtSize(d.size_bytes)}</small></td><td>{d.drive}</td><td className="mono">{d.serial || 'Not available'}</td>
            <td><Badge level={d.connected ? 'Connected' : 'Disconnected'} /></td><td>{fmtDate(d.connected_at)}</td><td>{fmtDate(d.last_scan_at)}</td><td><RiskBadge level={d.risk_level} score={d.risk_score} /></td>
            <td className="row"><button className="btn" onClick={() => open(d)}><Eye size={14} /> Details</button>
              {d.connected && <button className="btn primary" disabled={scanning(d.id)} onClick={() => scan(d)}><ScanLine size={14} /> {scanning(d.id) ? 'Scanning…' : d.last_scan_at ? 'Rescan' : 'Scan USB'}</button>}</td></tr>)}</tbody></table></div>
      </State></Card>
      {sel && <Modal title={sel.label} onClose={() => setSel(null)}>
        <dl className="dl"><dt>Drive</dt><dd>{sel.drive}</dd><dt>File system</dt><dd>{sel.filesystem}</dd><dt>Capacity</dt><dd>{fmtSize(sel.size_bytes)}</dd><dt>Volume serial</dt><dd className="mono">{sel.serial || 'Not available'}</dd>
          <dt>Connected</dt><dd>{fmtDate(sel.connected_at)}</dd><dt>Disconnected</dt><dd>{fmtDate(sel.disconnected_at)}</dd><dt>Risk</dt><dd><RiskBadge level={sel.risk_level} score={sel.risk_score} /></dd></dl>
        <h4>Why this risk level</h4><pre>{sel.risk_reasons || 'Not scanned yet.'}</pre>
        <h4>Scan history</h4>{sel.scans.length ? sel.scans.map((s) => <div className="li" key={s.id}><Badge level={s.status} /><div><b>Scan #{s.id}</b><small>{s.total_files} files · {s.skipped_files} skipped · {s.suspicious_files} suspicious · {fmtDate(s.finished_at)}</small></div></div>) : <p>No scans yet.</p>}
      </Modal>}
    </>
  );
}
