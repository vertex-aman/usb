import { useApp } from '../hooks/useApp.jsx';
import { Card, PageHead, State, RiskBadge } from '../components/UI.jsx';

export default function Risk() {
  const { devices, loading, error, reload } = useApp();
  return (
    <>
      <PageHead title="Risk Assessment" sub="Scores come from the backend risk engine (backend/app/risk_engine.py)." />
      <Card title="Bands"><div className="bands"><span className="badge low">0–24 Low</span><span className="badge medium">25–49 Medium</span><span className="badge high">50–74 High</span><span className="badge critical">75–100 Critical</span></div></Card>
      <State loading={loading} error={error} empty={!devices.length} onRetry={reload}>
        <div className="grid2">{devices.map((d) => (
          <Card key={d.id} title={`${d.label} (${d.drive})`} action={<RiskBadge level={d.risk_level} score={d.risk_score} />}>
            <div className={`meter ${(d.risk_level || '').toLowerCase()}`}><div style={{ width: (d.risk_score || 0) + '%' }} /></div>
            <h4>Reasons</h4><pre>{d.risk_reasons || 'Not scanned yet.'}</pre>
          </Card>))}</div>
      </State>
    </>
  );
}
