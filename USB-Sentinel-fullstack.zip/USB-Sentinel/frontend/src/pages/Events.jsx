import { useMemo, useState } from 'react';
import { useApp } from '../hooks/useApp.jsx';
import { Card, PageHead, SearchBox, Select, State, Badge } from '../components/UI.jsx';
import { fmtDate } from '../utils/index.js';

export default function Events() {
  const { events, loading, error, reload } = useApp();
  const [q, setQ] = useState(''); const [f, setF] = useState('All');
  const types = ['All', ...new Set(events.map((e) => e.type))];
  const rows = useMemo(() => events.filter((e) => (f === 'All' || e.type === f) && `${e.device} ${e.message}`.toLowerCase().includes(q.toLowerCase())), [events, q, f]);
  return (
    <>
      <PageHead title="Security Events" sub="Insertions, removals, scans, findings and agent status."><SearchBox value={q} onChange={setQ} /><Select value={f} onChange={setF} options={types} /></PageHead>
      <Card><State loading={loading} error={error} empty={!rows.length} onRetry={reload}>
        <div className="scroll"><table><thead><tr><th>Time</th><th>Type</th><th>Device</th><th>Detail</th></tr></thead>
          <tbody>{rows.map((e) => <tr key={e.id}><td>{fmtDate(e.time)}</td><td><Badge level={e.type}>{e.type}</Badge></td><td>{e.device || '—'}</td><td>{e.message}</td></tr>)}</tbody></table></div>
      </State></Card>
    </>
  );
}
