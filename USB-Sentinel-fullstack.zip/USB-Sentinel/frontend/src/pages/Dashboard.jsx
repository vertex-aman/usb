import { useApp } from '../hooks/useApp.jsx';
import { Card, PageHead, Badge, State, Doughnut } from '../components/UI.jsx';
import { fmtDate } from '../utils/index.js';

export default function Dashboard() {
  const { dashboard: d, events, alerts, loading, error, reload } = useApp();
  const stats = d && [['Total USB devices', d.total_devices], ['Connected now', d.connected_devices], ['Files scanned', d.files_scanned], ['Suspicious files', d.suspicious_files], ['High / Critical findings', d.high_critical], ['Scans running', d.running_scans]];
  const labels = d && Object.keys(d.distribution);
  return (
    <>
      <PageHead title="Dashboard" sub="Live overview from your backend and agent (refreshes every 3 s)" />
      <State loading={loading} error={error} onRetry={reload}>{d && <>
        <div className="grid4">{stats.map(([k, v]) => <div className="card stat" key={k}><span>{k}</span><b>{v}</b></div>)}</div>
        <div className="grid2">
          <Card title="Agent status"><div className={`status ${d.agent_online ? 'low' : 'critical'}`}><b>{d.agent_online ? 'Agent connected' : 'Agent disconnected'}</b><span>{d.agent_online ? `Last heartbeat ${fmtDate(d.agent_last_seen)}` : 'Start agent/agent.py on the monitored PC'}</span></div></Card>
          <Card title="Device risk distribution"><Doughnut labels={labels} values={labels.map((l) => d.distribution[l])} colors={['#22c55e', '#eab308', '#f97316', '#ef4444', '#3b4a5f']} /></Card>
          <Card title="Recent USB events">{events.length ? events.slice(0, 6).map((e) => <div className="li" key={e.id}><Badge level={e.type}>{e.type}</Badge><div><b>{e.device || '—'}</b><small>{e.message} · {fmtDate(e.time)}</small></div></div>) : <div className="state">No events yet. Insert a USB drive.</div>}</Card>
          <Card title="Recent scan results">{d.recent_scans.length ? d.recent_scans.map((s) => <div className="li" key={s.id}><Badge level={s.status} /><div><b>{s.device} · {s.drive}</b><small>{s.total_files} files · {s.suspicious_files} suspicious · {s.risk_level || 'no risk result yet'}</small></div></div>) : <div className="state">No scans yet.</div>}</Card>
          <Card title="Recent alerts">{alerts.length ? alerts.slice(0, 4).map((a) => <div className="li" key={a.id}><Badge level={a.severity} /><div><b>{a.title}</b><small>{a.file} · {a.device}</small></div></div>) : <div className="state">No alerts.</div>}</Card>
        </div></>}
      </State>
    </>
  );
}
