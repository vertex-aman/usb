import { useState } from 'react';
import { useApp } from '../hooks/useApp.jsx';
import { api, errMsg } from '../services/api.js';
import { Card, PageHead, Select, State, Badge, Modal } from '../components/UI.jsx';
import { fmtDate } from '../utils/index.js';

export default function Alerts() {
  const { alerts, loading, error, reload, toast } = useApp();
  const [f, setF] = useState('All'); const [sel, setSel] = useState(null);
  const rows = alerts.filter((a) => f === 'All' || a.severity === f);
  const ack = async () => { try { await api.ackAlert(sel.id); toast('Alert acknowledged', 'success'); setSel(null); reload(); } catch (e) { toast(errMsg(e), 'error'); } };
  return (
    <>
      <PageHead title="Alerts" sub="Significant findings from real scans."><Select value={f} onChange={setF} options={['All', 'Critical', 'High']} /></PageHead>
      <Card><State loading={loading} error={error} empty={!rows.length} onRetry={reload}>
        {rows.map((a) => <div className="li click" key={a.id} onClick={() => setSel(a)}><Badge level={a.severity} /><div><b>{a.file}</b><small>{a.device} · {fmtDate(a.time)}</small></div><Badge level={a.status} /></div>)}
      </State></Card>
      {sel && <Modal title={sel.title} onClose={() => setSel(null)}>
        <p><Badge level={sel.severity} /> <Badge level={sel.status} /></p><dl className="dl"><dt>File</dt><dd>{sel.file}</dd><dt>Device</dt><dd>{sel.device}</dd><dt>Time</dt><dd>{fmtDate(sel.time)}</dd><dt>Reason</dt><dd>{sel.reason}</dd></dl>
        <h4>Recommended actions</h4><ul><li>Do not open or run the file.</li><li>Remove the drive and scan it with your antivirus.</li><li>Check the SHA-256 on virustotal.com.</li></ul>
        <br /><button className="btn primary" disabled={sel.status !== 'Open'} onClick={ack}>Acknowledge</button>
      </Modal>}
    </>
  );
}
