import { Routes, Route } from 'react-router-dom';
import Layout from './layouts/Layout.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Devices from './pages/Devices.jsx';
import FileAnalysis from './pages/FileAnalysis.jsx';
import Risk from './pages/Risk.jsx';
import Events from './pages/Events.jsx';
import Alerts from './pages/Alerts.jsx';
import Reports from './pages/Reports.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="devices" element={<Devices />} />
        <Route path="files" element={<FileAnalysis />} />
        <Route path="risk" element={<Risk />} />
        <Route path="events" element={<Events />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="reports" element={<Reports />} />
        <Route path="*" element={<div className="state">Page not found.</div>} />
      </Route>
    </Routes>
  );
}
