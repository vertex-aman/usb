import axios from 'axios';
// All data comes from the FastAPI backend. Nothing here is simulated.
export const http = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api', timeout: 10000 });
export const api = {
  dashboard: () => http.get('/dashboard').then((r) => r.data),
  devices: () => http.get('/devices').then((r) => r.data),
  device: (id) => http.get(`/devices/${id}`).then((r) => r.data),
  scanDevice: (id) => http.post(`/devices/${id}/scan`).then((r) => r.data),
  files: (params) => http.get('/files', { params }).then((r) => r.data),
  events: () => http.get('/events').then((r) => r.data),
  alerts: () => http.get('/alerts').then((r) => r.data),
  ackAlert: (id) => http.patch(`/alerts/${id}`).then((r) => r.data),
};
export const errMsg = (e) => e?.response?.data?.detail || (e?.code === 'ERR_NETWORK' ? 'Backend unavailable' : e?.message || 'Request failed');
