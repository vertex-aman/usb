import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { ShieldCheck, LayoutDashboard, Usb, FileSearch, Gauge, Activity, Bell, FileText, Menu } from 'lucide-react';
import { useApp } from '../hooks/useApp.jsx';

const nav = [['/', 'Dashboard', LayoutDashboard], ['/devices', 'USB Devices', Usb], ['/files', 'File Analysis', FileSearch], ['/risk', 'Risk Assessment', Gauge], ['/events', 'Security Events', Activity], ['/alerts', 'Alerts', Bell], ['/reports', 'Reports', FileText]];

export default function Layout() {
  const [open, setOpen] = useState(false);
  const { alerts, dashboard, error } = useApp();
  const openCount = alerts.filter((a) => a.status === 'Open').length;
  return (
    <div className="shell">
      <aside className={open ? 'side open' : 'side'}>
        <div className="brand"><ShieldCheck size={26} /><div><b>USB Sentinel</b><small>Monitoring & Risk</small></div></div>
        <nav>{nav.map(([to, label, Icon]) => (
          <NavLink key={to} to={to} end={to === '/'} onClick={() => setOpen(false)}><Icon size={18} />{label}{label === 'Alerts' && openCount > 0 && <em>{openCount}</em>}</NavLink>
        ))}</nav>
        <div className="sidefoot">Live data from your backend</div>
      </aside>
      <div className="main">
        <header className="topbar">
          <button className="icon menu" onClick={() => setOpen(!open)} aria-label="Menu"><Menu /></button>
          <span className="pill"><i className={error ? 'dot' : 'dot ok'} /> Backend: {error ? 'unavailable' : 'online'}</span>
          <span className="pill"><i className={dashboard?.agent_online ? 'dot ok' : 'dot'} /> Agent: {dashboard?.agent_online ? 'connected' : 'disconnected'}</span>
        </header>
        <main><Outlet /></main>
      </div>
    </div>
  );
}
