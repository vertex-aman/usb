import { useEffect, useRef, useState } from 'react';
import { Chart, DoughnutController, ArcElement, Tooltip, Legend } from 'chart.js';
import { X, Search, Loader2, AlertTriangle, Inbox } from 'lucide-react';
Chart.register(DoughnutController, ArcElement, Tooltip, Legend);

export const Badge = ({ level, children }) => <span className={`badge ${String(level).toLowerCase().replace(/\s/g, '-')}`}>{children || level}</span>;
export const RiskBadge = ({ level, score }) => (level ? <Badge level={level}>{score != null ? `${score} · ` : ''}{level}</Badge> : <Badge level="Unscanned">Unscanned</Badge>);
export const Card = ({ title, action, children }) => <section className="card">{title && <header><h3>{title}</h3>{action}</header>}{children}</section>;
export const PageHead = ({ title, sub, children }) => <div className="pagehead"><div><h1>{title}</h1><p>{sub}</p></div><div className="row">{children}</div></div>;

export function SearchBox({ value, onChange, placeholder = 'Search…' }) {
  return <label className="search"><Search size={16} /><input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} /></label>;
}
export function Select({ value, onChange, options }) {
  return <select className="select" value={value} onChange={(e) => onChange(e.target.value)}>{options.map((o) => <option key={o}>{o}</option>)}</select>;
}
export function State({ loading, error, empty, onRetry, children }) {
  if (loading) return <div className="state"><Loader2 className="spin" /> Loading…</div>;
  if (error) return <div className="state err"><AlertTriangle /> {error}<button className="btn" onClick={onRetry}>Retry</button></div>;
  if (empty) return <div className="state"><Inbox /> Nothing to show.</div>;
  return children;
}
export function Modal({ title, onClose, children }) {
  useEffect(() => { const k = (e) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);
  return <div className="overlay" onClick={onClose}><div className="modal" onClick={(e) => e.stopPropagation()}><header><h3>{title}</h3><button className="icon" onClick={onClose} aria-label="Close"><X size={18} /></button></header>{children}</div></div>;
}
export function Doughnut({ labels, values, colors }) {
  const ref = useRef(); const [chart, setChart] = useState(null);
  useEffect(() => {
    const c = new Chart(ref.current, { type: 'doughnut', data: { labels, datasets: [{ data: values, backgroundColor: colors, borderWidth: 0 }] }, options: { cutout: '68%', plugins: { legend: { position: 'bottom', labels: { color: '#9fb0c3' } } } } });
    setChart(c); return () => c.destroy();
  }, [JSON.stringify(values)]);
  return <div className="chart"><canvas ref={ref} /></div>;
}
