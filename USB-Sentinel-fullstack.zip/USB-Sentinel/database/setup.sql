-- Run once as the MySQL root user. Tables are created automatically when the backend first starts.
CREATE DATABASE IF NOT EXISTS usb_sentinel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'usb_user'@'localhost' IDENTIFIED BY 'change_me';
GRANT ALL PRIVILEGES ON usb_sentinel.* TO 'usb_user'@'localhost';
FLUSH PRIVILEGES;
