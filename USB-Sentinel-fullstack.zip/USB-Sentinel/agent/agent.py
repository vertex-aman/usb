"""USB Sentinel system agent (Windows). Reuses usb.py, scanner.py and hashing.py from the project root.
Read-only: it never opens files for execution, deletes, or modifies anything."""
import os, sys, time, socket
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import requests
from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, ".env"))
from usb import get_usb_drives
from scanner import scan_drive
from hashing import calculate_hash

API = os.getenv("API_URL", "http://localhost:8000/api").rstrip("/")
HEAD = {"X-Agent-Key": os.getenv("AGENT_KEY", "")}
MAX_BYTES = 200 * 1024 * 1024   # files above this are recorded as skipped
BATCH = 100

def call(method, path, **kw):
    try:
        r = requests.request(method, API + path, headers=HEAD, timeout=15, **kw)
        if r.status_code == 401: print("!! AGENT_KEY rejected by backend. Check .env"); return None
        r.raise_for_status(); return r.json()
    except requests.RequestException as e:
        print(f"[backend unavailable] {e.__class__.__name__}; will retry"); return None

def run_scan(scan, drives):
    sid, drive = scan["id"], scan["drive"]
    if drive not in drives:
        return call("POST", f"/agent/scans/{sid}/complete", json={"ok": False, "error": "Drive is no longer connected"})
    print(f"Scanning {drive} (scan #{sid})")
    try:
        files, _ = scan_drive(drive); batch = []
        for f in files:
            item = {"name": f["name"], "path": f["path"], "extension": f["extension"], "size": f["size"]}
            if f["size"] > MAX_BYTES: item["skipped"] = True
            else:
                h = calculate_hash(f["path"])
                if len(h) == 64: item["sha256"] = h
                else: item["skipped"] = True
            batch.append(item)
            if len(batch) >= BATCH:
                call("POST", f"/agent/scans/{sid}/files", json=batch); batch = []
        if batch: call("POST", f"/agent/scans/{sid}/files", json=batch)
        call("POST", f"/agent/scans/{sid}/complete", json={"ok": True})
        print(f"Scan #{sid} done: {len(files)} files")
    except Exception as e:
        call("POST", f"/agent/scans/{sid}/complete", json={"ok": False, "error": str(e)[:500]})

def main():
    print("USB Sentinel agent running. Press Ctrl+C to stop.")
    reported = {}
    while True:
        drives = {d["drive"]: d for d in get_usb_drives()}
        call("POST", "/agent/heartbeat", json={"hostname": socket.gethostname()})
        for k, d in drives.items():
            if k not in reported and call("POST", "/agent/device-event", json={"event": "connected", **d}) is not None:
                reported[k] = d; print("Connected:", k, d["label"])
        for k in list(reported):
            if k not in drives and call("POST", "/agent/device-event", json={"event": "disconnected", **reported[k]}) is not None:
                del reported[k]; print("Removed:", k)
        for s in call("GET", "/agent/pending-scans") or []:
            run_scan(s, drives)
        time.sleep(3)

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("Agent stopped.")
