import os

SUSPICIOUS_EXTENSIONS = {
    ".exe",
    ".dll",
    ".bat",
    ".cmd",
    ".vbs",
    ".ps1",
    ".js",
    ".scr",
    ".msi",
    ".com",
    ".jar",
    ".hta",
    ".inf"
}


def scan_drive(drive):

    files = []
    suspicious = []

    for root, dirs, filenames in os.walk(drive):

        for file in filenames:

            full_path = os.path.join(root, file)

            try:
                size = os.path.getsize(full_path)
                ext = os.path.splitext(file)[1].lower()

                file_info = {
                    "name": file,
                    "path": full_path,
                    "size": size,
                    "extension": ext
                }

                files.append(file_info)

                if ext in SUSPICIOUS_EXTENSIONS:
                    suspicious.append(file_info)

            except Exception:
                pass

    return files, suspicious